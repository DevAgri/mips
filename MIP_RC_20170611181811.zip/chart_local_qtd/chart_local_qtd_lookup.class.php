<?php
class chart_local_qtd_lookup
{
}
?>
