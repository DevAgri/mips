<?php 
  include_once('../chart_local_qtd/index.php'); 
?> 
