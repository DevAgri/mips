<?php 
  include_once('../chart_data_qtd/index.php'); 
?> 
