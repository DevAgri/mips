<?php
class chart_data_qtd_lookup
{
}
?>
