<?php 
  include_once('../app_change_pswd/index.php'); 
?> 
