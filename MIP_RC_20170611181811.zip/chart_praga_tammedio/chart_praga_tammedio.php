<?php 
  include_once('../chart_praga_tammedio/index.php'); 
?> 
