<?php 
  include_once('../chart_praga_qtd/index.php'); 
?> 
