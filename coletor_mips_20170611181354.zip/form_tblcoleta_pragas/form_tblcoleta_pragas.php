<?php 
  include_once('../form_tblcoleta_pragas/index.php'); 
?> 
