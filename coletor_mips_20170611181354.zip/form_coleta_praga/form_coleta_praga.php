<?php 
  include_once('../form_coleta_praga/index.php'); 
?> 
