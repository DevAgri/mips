<?php 
  include_once('../chart_tblcoleta_pragas/index.php'); 
?> 
