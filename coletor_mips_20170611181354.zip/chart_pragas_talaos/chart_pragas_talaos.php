<?php 
  include_once('../chart_pragas_talaos/index.php'); 
?> 
